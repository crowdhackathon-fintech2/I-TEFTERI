# Postman Collections
List of all the files in this directory.
```
- ibank Pay Sandbox Api
  - [postman collection](ibank.pay.sandbox.api.v1.postman_collection.json) 
- Open Bank Sandbox Api 
  - [postman collection](iOpen Api Sandbox Scenarios.postman_collection.json) 
  - [postman environment](iOpenApiSandbox Scenarios.postman_environment.json) 
```
